#!/bin/bash
# Clone/pin upstream Horizon and overlay the iOS port crate, its four data
# crates, and the patch that adds them.
#
# Inputs:
#   HORIZON_DIR  upstream checkout (default: sibling ../horizon)
set -euxo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HORIZON_DIR="${HORIZON_DIR:-$ROOT/../horizon}"
PIN="69ab572dbd1bf2f2924a424f791014e09d9d0b50"

if [ ! -d "$HORIZON_DIR/.git" ]; then
    git clone --depth 1 https://github.com/horizon-rust/horizon.git "$HORIZON_DIR"
fi

git -C "$HORIZON_DIR" fetch --depth 1 origin "$PIN"
git -C "$HORIZON_DIR" checkout --force "$PIN"

# The port crate plus the four crates it depends on.
rm -rf "$HORIZON_DIR/crates/horizon-ios"
cp -R "$ROOT/port/horizon-ios" "$HORIZON_DIR/crates/horizon-ios"

for crate in hzr-pack hzr-fetch hzr-device hzr-download; do
    rm -rf "$HORIZON_DIR/crates/$crate"
    cp -R "$ROOT/port/$crate" "$HORIZON_DIR/crates/$crate"
done

python3 - "$HORIZON_DIR" <<'PY'
import sys
from pathlib import Path

root = Path(sys.argv[1])
members = ["horizon-ios", "hzr-pack", "hzr-fetch", "hzr-device", "hzr-download"]

# Each crate ships with a standalone `[workspace]` so it can be tested on its
# own; inside Horizon it has to join the parent workspace instead.
for crate in members:
    manifest = root / "crates" / crate / "Cargo.toml"
    lines = manifest.read_text().splitlines()
    kept = [line for line in lines if line.strip() != "[workspace]"]
    manifest.write_text("\n".join(kept).rstrip() + "\n")

workspace = root / "Cargo.toml"
text = workspace.read_text()
for crate in members:
    marker = f'"crates/{crate}"'
    if marker not in text:
        text = text.replace("members = [", "members = [\n    " + marker + ",", 1)
workspace.write_text(text)
PY

if git -C "$HORIZON_DIR" apply --check "$ROOT/patches/ios-deps.patch"; then
    git -C "$HORIZON_DIR" apply "$ROOT/patches/ios-deps.patch"
elif git -C "$HORIZON_DIR" apply --reverse --check "$ROOT/patches/ios-deps.patch"; then
    echo "iOS patch already applied"
else
    echo "iOS patch does not apply to $PIN" >&2
    exit 1
fi

if git -C "$HORIZON_DIR" apply --check "$ROOT/patches/ios-metal.patch"; then
    git -C "$HORIZON_DIR" apply "$ROOT/patches/ios-metal.patch"
elif git -C "$HORIZON_DIR" apply --reverse --check "$ROOT/patches/ios-metal.patch"; then
    echo "iOS Metal patch already applied"
else
    echo "iOS Metal patch does not apply to $PIN" >&2
    exit 1
fi

if git -C "$HORIZON_DIR" apply --check "$ROOT/patches/ios-resource-wait.patch"; then
    git -C "$HORIZON_DIR" apply "$ROOT/patches/ios-resource-wait.patch"
elif git -C "$HORIZON_DIR" apply --reverse --check "$ROOT/patches/ios-resource-wait.patch"; then
    echo "iOS resource wait patch already applied"
else
    echo "iOS resource wait patch does not apply to $PIN" >&2
    exit 1
fi

if git -C "$HORIZON_DIR" apply --check "$ROOT/patches/ios-rest-join.patch"; then
    git -C "$HORIZON_DIR" apply "$ROOT/patches/ios-rest-join.patch"
elif git -C "$HORIZON_DIR" apply --reverse --check "$ROOT/patches/ios-rest-join.patch"; then
    echo "iOS rest join patch already applied"
else
    echo "iOS rest join patch does not apply to $PIN" >&2
    exit 1
fi

echo "prepared $HORIZON_DIR at $PIN"
