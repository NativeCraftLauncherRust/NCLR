# NCLR L1 · 单 App：启动器覆盖在已启动引擎上

作者：**ZRXMAXLNX**、**可心**  
平台：iOS 15+ / arm64 / 横屏  
版本：**L1** 开发者测试版

---

## 1. 单 App 方案

L1 现在是一个 IPA / 一个 App：

- 启动时引擎先初始化自己的 `UIApplicationMain` 和游戏窗口；
- 启动器作为**更高 window level 的窗口**盖在游戏窗口上；
- 所以每次打开 NCLR，看到的都是启动器；
- 点“启动游戏”只是**隐藏启动器窗口**，露出已经启动的引擎；
- 不退出、不重启、不跳转外部 App。

这解决了前几版的两个问题：

- 不再需要退出重开才能进游戏；
- 不会再出现两个 App 的 IPA 导入问题。

**代价**：引擎在启动器显示时已经在后台预启动，而不是点按钮那一刻才开始运行。  
iOS 的 winit 引擎必须自己调用 `UIApplicationMain`；要让启动器永远先出现，这是不退出进程的唯一做法。

---

## 2. 启动器

- 主页 / 版本 / 模组 / 账号 / 设置；
- 默认 **正版用户（开发者默认）**，不强制登录；
- 内置 `26.3` 完整资源树，引擎和启动器同一个容器；
- 设置 → **编辑游戏内按键映射**：
  - 上方可收起的“按键设置”小菜单；
  - 展开后是标注为 **按键大小** 的滑条（0.50x–2.00x）；
  - 中间是 **游戏内布局预览**，按钮可拖动改变位置；
  - **+ 添加按键** 可以增加新按键；
  - 底部 **保存** / **退出**；
  - 保存到：

```text
Documents/keymap.json
```

JSON 包含：

```json
{
  "buttonSize": 1.0,
  "bindings": { "forward": "W", "jump": "Space" },
  "layout": {
    "forward": { "x": 0.13, "y": 0.76, "size": 0.16 }
  }
}
```

**当前边界**：L1 完成了启动器里的游戏布局编辑器、拖动、添加按键、大小滑条、保存/退出和 JSON 落盘。  
引擎读取 `keymap.json` 并应用到 Horizon `TouchControls` 的钩子还没有接上；当前引擎仍用自己的触屏布局。下一步是在引擎启动时读取这个文件并替换布局。

---

## 3. 文件

| 文件 | 大小 | SHA-256 |
|---|---:|---|
| `NCLR-L1-signed.ipa` | 105,098,159 B | `3B0DAE40…688DEB19` |
| `NCLR-L1-unsigned.ipa` | 104,975,560 B | `451333F6…85CC8B8C` |

- 已签名包：Bundle ID `app.badger212.aries5602`，只绑定 UDID 以 `0E7A401E` 结尾的设备；
- 未签名包：Bundle ID `dev.zrxmaxlnx.nclr`；
- 版本：`L1`（CFBundleShortVersionString `1.0`，CFBundleVersion `202611190728`）；
- 包内引擎：Horizon 26.3 / route3 iOS 静态库（含 Metal 修复）；
- 包内资源：完整 `horizon-client/26.3`。

---

## 4. 这次闪退的原因与修复

归档里的 `latest.log`：

```text
Horizon renderer: Apple A18 Pro GPU (Metal, IntegratedGpu)
world renderer ready after 10675 ms
panicked at .../game/runtime/resource_tables.rs:28:14:
world resources joined before entry
```

不是 Metal/黑屏问题，而是 **世界资源后台加载还没完成，标题界面就读取 `Resources::rest()`，
旧代码直接 `expect` 崩溃**。  
L1 先加了 `ios-resource-wait.patch`，让读取方等待；但 `latest(11).log` 显示 loader 已打印
`resources loaded in 9.8s`，`rest` 仍未发布，标题一直 `waiting for world resources`。  
所以又加了 `ios-rest-join.patch`：**在把资源交给标题界面前，先 join 世界资源 loader**，
让加载画面多停留一会儿，避免标题空转。启动时可能晚几秒进标题，但不会再停在
`waiting for world resources`。

---

## 5. 安装

1. 删除旧的 HorizonEngine / 旧 NCLR / 旧独立游戏端；
2. 用 Sideloadly 安装 **NCLR-L1-signed.ipa**（已签名设备）  
   或 **NCLR-L1-unsigned.ipa**（自己的 Apple ID 重签）；
3. 打开 NCLR，应直接看到启动器；
4. 点“启动游戏”，启动器隐藏，进入引擎；
5. 下次从主屏幕打开 NCLR，仍然先进入启动器。

包压缩后约 105 MB，安装后约 430 MB。

---

## 6. 当前边界

- 引擎在启动器显示时已预启动；点“启动游戏”只是切换窗口，不是冷启动。
- 引擎读取 keymap/版本/模组配置的钩子尚未完成；L1 先把单 App 启动链、资源、启动器和编辑器做好。
- 默认正版仅用于 L1 开发者测试，不是正式分发/绕过购买。
- 未在真机上复验本包；若进引擎黑屏，请发 `NCLR` 的 `.ips` 或 `idevicesyslog`。
- 不是 Mojang / Microsoft 官方产品。

---

## 7. 构建来源

- 入口：`ios/main_l1.m`
- Info：`ios/Info-launcher.plist`
- 构建：`ios/build.sh`，CircleCI #22
- 资源：`resources/26.3`（构建后注入并重签）
- 作者：**ZRXMAXLNX**、**可心**
